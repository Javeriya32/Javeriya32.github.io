import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function WeatherModule(){
  const [city, setCity] = useState('London');
  const [data, setData] = useState(null);
  const [isLoading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchWeather = async (c) => {
    try {
      setError(''); setLoading(true);
      const r = await axios.get(`/api/weather?city=${encodeURIComponent(c)}`);
      setData(r.data);
    } catch (e) {
      setError('Failed to load weather.');
    } finally { setLoading(false); }
  };

  useEffect(()=>{ fetchWeather(city); }, []);

  return (
    <div>
      <div style={{marginBottom:12}}>
        <input value={city} onChange={e=>setCity(e.target.value)} style={{padding:8, borderRadius:6, border:'1px solid #ddd', marginRight:8}} />
        <button onClick={()=>fetchWeather(city)} style={{padding:'8px 12px', borderRadius:6}}>Get</button>
      </div>

      {isLoading && <div>Loading...</div>}
      {error && <div style={{color:'#c00'}}>{error}</div>}
      {data && !isLoading && !error && (
        <div>
          <h3 style={{margin:'6px 0'}}>{data.city} — {data.description}</h3>
          <p style={{margin:'4px 0'}}>Temperature: {data.tempC}°C</p>
          <small style={{color:'#666'}}>Source: {data.source}</small>
        </div>
      )}
    </div>
  )
}
