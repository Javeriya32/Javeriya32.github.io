import React, { useState } from 'react';
import axios from 'axios';

export default function CurrencyConverter(){
  const [amount, setAmount] = useState(100);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');

  const convert = async () => {
    try {
      setErr(''); setLoading(true);
      const r = await axios.get(`/api/currency?amount=${encodeURIComponent(amount)}`);
      setResult(r.data);
    } catch(e) {
      setErr('Conversion failed.');
    } finally { setLoading(false); }
  };

  return (
    <div>
      <div style={{marginBottom:12}}>
        <input type="number" value={amount} onChange={e=>setAmount(e.target.value)} style={{padding:8, borderRadius:6, border:'1px solid #ddd', marginRight:8, width:140}} />
        <button onClick={convert} style={{padding:'8px 12px', borderRadius:6}}>Convert</button>
      </div>

      {loading && <div>Loading...</div>}
      {err && <div style={{color:'#c00'}}>{err}</div>}
      {result && (
        <div>
          <p style={{margin:'6px 0'}}>INR: {result.amountINR}</p>
          <p style={{margin:'6px 0'}}>USD: {result.usd}</p>
          <p style={{margin:'6px 0'}}>EUR: {result.eur}</p>
          <small style={{color:'#666'}}>Source: {result.source}</small>
        </div>
      )}
    </div>
  )
}
