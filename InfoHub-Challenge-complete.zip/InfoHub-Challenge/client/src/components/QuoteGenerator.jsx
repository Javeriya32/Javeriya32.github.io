import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function QuoteGenerator(){
  const [quote, setQuote] = useState(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');

  const load = async () => {
    try {
      setErr(''); setLoading(true);
      const r = await axios.get('/api/quote');
      setQuote(r.data);
    } catch(e) {
      setErr('Could not load quote.');
    } finally { setLoading(false); }
  };

  useEffect(()=>{ load(); }, []);

  return (
    <div>
      <button onClick={load} style={{padding:'8px 12px', borderRadius:6, marginBottom:12}}>New Quote</button>
      {loading && <div>Loading...</div>}
      {err && <div style={{color:'#c00'}}>{err}</div>}
      {quote && !loading && (
        <blockquote style={{margin:0, paddingLeft:12, borderLeft:'3px solid #eee'}}>
          <p style={{margin:'6px 0'}}>"{quote.content}"</p>
          <footer style={{color:'#666'}}>- {quote.author} <small>({quote.source})</small></footer>
        </blockquote>
      )}
    </div>
  )
}
