import React, { useState } from 'react';
import WeatherModule from './components/WeatherModule';
import CurrencyConverter from './components/CurrencyConverter';
import QuoteGenerator from './components/QuoteGenerator';

export default function App() {
  const [active, setActive] = useState('Weather');
  return (
    <div style={{maxWidth:760, margin:'0 auto', padding:20}}>
      <header style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12}}>
        <h1 style={{margin:0}}>InfoHub</h1>
        <small style={{color:'#666'}}>Small full-stack demo</small>
      </header>

      <nav style={{display:'flex', gap:8, marginBottom:16}}>
        {['Weather','Currency','Quote'].map(tab => (
          <button
            key={tab}
            onClick={() => setActive(tab)}
            style={{
              padding:'8px 12px',
              borderRadius:8,
              border: '1px solid #ddd',
              background: active===tab ? '#111' : '#fff',
              color: active===tab ? '#fff' : '#111'
            }}
          >
            {tab}
          </button>
        ))}
      </nav>

      <main style={{background:'#fff', padding:16, borderRadius:8, boxShadow:'0 6px 20px rgba(15,15,15,0.05)'}}>
        {active==='Weather' && <WeatherModule />}
        {active==='Currency' && <CurrencyConverter />}
        {active==='Quote' && <QuoteGenerator />}
      </main>

      <footer style={{marginTop:16, color:'#666', fontSize:13}}>
        <div>Made for ByteXL — InfoHub challenge</div>
      </footer>
    </div>
  );
}
