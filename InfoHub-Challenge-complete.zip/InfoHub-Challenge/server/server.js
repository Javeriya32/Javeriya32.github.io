require('dotenv').config();
const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3001;

// Simple local quote list fallback
const LOCAL_QUOTES = [
  { content: "The only way to do great work is to love what you do.", author: "Steve Jobs" },
  { content: "Start where you are. Use what you have. Do what you can.", author: "Arthur Ashe" },
  { content: "Success is not final; failure is not fatal: It is the courage to continue that counts.", author: "Winston Churchill" }
];

// /api/quote -> returns a random quote (tries Quotable API first, then fallback)
app.get('/api/quote', async (req, res) => {
  try {
    const r = await axios.get('https://api.quotable.io/random');
    const { content, author } = r.data;
    return res.json({ content, author, source: 'quotable' });
  } catch (err) {
    const q = LOCAL_QUOTES[Math.floor(Math.random() * LOCAL_QUOTES.length)];
    return res.json({ ...q, source: 'local' });
  }
});

// /api/weather?city=CityName -> returns { tempC, description, city }
// Uses OpenWeatherMap (Current Weather)
app.get('/api/weather', async (req, res) => {
  try {
    const city = req.query.city || 'London';
    const key = process.env.OPENWEATHER_KEY;
    if (!key) {
      return res.json({ city, tempC: 20, description: 'Clear sky (mock)', source: 'mock' });
    }
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${key}&units=metric`;
    const r = await axios.get(url);
    const tempC = r.data.main.temp;
    const description = r.data.weather?.[0]?.description || 'N/A';
    return res.json({ city: r.data.name, tempC, description, source: 'openweather' });
  } catch (err) {
    console.error(err && err.message);
    return res.status(500).json({ error: 'Could not fetch weather data.' });
  }
});

// /api/currency?amount=100
// Converts INR -> USD & EUR using ExchangeRate-API (or fallback mock)
app.get('/api/currency', async (req, res) => {
  try {
    const amount = parseFloat(req.query.amount) || 1;
    const key = process.env.EXCHANGERATE_KEY;
    if (key) {
      const url = `https://v6.exchangerate-api.com/v6/${key}/latest/INR`;
      const r = await axios.get(url);
      const rates = r.data.conversion_rates || r.data.rates;
      const usdRate = rates['USD'];
      const eurRate = rates['EUR'];
      if (!usdRate || !eurRate) throw new Error('Missing rates');
      return res.json({
        amountINR: amount,
        usd: +(amount * usdRate).toFixed(4),
        eur: +(amount * eurRate).toFixed(4),
        source: 'exchangerate-api'
      });
    } else {
      const mockUsd = 0.012;
      const mockEur = 0.011;
      return res.json({
        amountINR: amount,
        usd: +(amount * mockUsd).toFixed(4),
        eur: +(amount * mockEur).toFixed(4),
        source: 'mock'
      });
    }
  } catch (err) {
    console.error(err && err.message);
    return res.status(500).json({ error: 'Could not fetch currency data.' });
  }
});

app.listen(PORT, () => {
  console.log(`InfoHub server listening on port ${PORT}`);
});
