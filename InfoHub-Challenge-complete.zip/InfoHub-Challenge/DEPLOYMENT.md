# Deployment Guide (quick)

You have two simple options to deploy this project.

## Option A — Deploy client + server separately (recommended, easiest)
1. Push repository to GitHub.
2. Deploy **client/** to Vercel (or Netlify) as a static site:
   - Build command: `npm run build`
   - Output directory: `dist`
3. Deploy **server/** to Render / Heroku / Railway (or serverless platform that supports Node):
   - Set environment variables: `OPENWEATHER_KEY`, `EXCHANGERATE_KEY` as needed.
   - Start command: `node server.js`
4. In the deployed client, set API base URL to the server's public URL (replace `/api` calls with `https://your-server.com/api` or set a runtime variable).

## Option B — Deploy combined on Vercel (monorepo)
Vercel supports serverless functions, but this repo uses a single Express server. To use Vercel serverless functions you must refactor `server/server.js` into individual functions under `api/`. Because that is a small change, here are the high-level steps:
- Convert each endpoint into a serverless function `api/weather.js`, `api/currency.js`, `api/quote.js` (move logic there).
- Deploy the repo to Vercel (it will detect functions in `api/`).
This is slightly more work but keeps everything in one place.

## Environment variables
When deploying, set:
- `OPENWEATHER_KEY` — (optional) API key for OpenWeatherMap
- `EXCHANGERATE_KEY` — (optional) API key for chosen exchange-rate provider

If you don't add keys, the server returns mock but sensible values so reviews/demos still work.

## Notes
- Do NOT commit `.env` containing your API keys.
- For a submission that will be graded immediately, deploy client to Vercel and server to Render (free tiers) — both have friendly UIs and straightforward env var setup.
