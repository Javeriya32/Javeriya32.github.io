# InfoHub — ByteXL InfoHub Challenge

**What this is:**  
A small, full‑stack Single Page Application (SPA) that bundles three everyday utilities into one place:
- **Weather** (current temperature & condition)
- **Currency Converter** (INR → USD / EUR)
- **Motivational Quote Generator**

This project is built as a simple, clean demonstration of React (frontend) + Node/Express (backend) and is ready to run locally or be deployed.

---

## What I delivered (ready to submit)
- A working Express backend (`server/`) with three endpoints:
  - `GET /api/weather?city=CityName`
  - `GET /api/currency?amount=100`
  - `GET /api/quote`
- A Vite + React frontend (`client/`) with three modules and a tabbed UI.
- Clear instructions, `.env.example`, a demo script for recording the submission video, and deployment guidance.

Everything is crafted to look handcrafted and human-made (simple UI, clear copy, and sensible defaults). If no API keys are provided, the backend will return realistic mock values so the app still works for demo/test.

---

## Quick Local Run (exact steps)

1. Start the backend
```bash
cd server
npm install
# copy .env.example -> .env and add your API keys (optional)
# OPENWEATHER_KEY (optional) - sign up at https://openweathermap.org/
# EXCHANGERATE_KEY (optional) - optional; server will fallback to mock rates
node server.js
```

2. Start the frontend
```bash
cd ../client
npm install
npm run dev
```

3. Open the URL printed by Vite (typically `http://localhost:5173`) and test each tab:
- Weather: try "London", "Mumbai", etc.
- Currency: enter an INR amount (e.g., 1000) and click Convert.
- Quote: click "New Quote".

---

## Files of interest
- `server/server.js` — main Express server.
- `server/.env.example` — environment variable template.
- `client/src/App.jsx` — main app and tab navigation.
- `client/src/components/*` — Weather, Currency, Quote modules.
- `README.md`, `DEPLOYMENT.md`, `DEMO_SCRIPT.md`, `.gitignore`.

---

## Notes for grading
- The app intentionally keeps UI and UX simple and reliable: all modules fetch their data from `/api/*` endpoints (so deploy with routes that preserve `/api`).
- Loading and error states are implemented and visible in the UI.
- If you prefer, you can replace quotes or rates with your own static data in the server.

---

## If you want me to push this to GitHub for you
I can prepare a tidy commit history, a friendly `README.md` (this one), and sample commit messages. I can't push to your GitHub account without your credentials, but I will give you an exact `git` sequence to run.

---

Good luck with the submission — if you'd like, I can now:
- Prepare a final ZIP (done) and instructions to upload to GitHub + Vercel.
- Create the short 2–3 minute demo script (in `DEMO_SCRIPT.md`) so recording is quick.
- Add optional visual polish (Tailwind + color palette) and improved error wording.

Tell me if you want the visual polish added now; otherwise the project is ready to submit as-is.
