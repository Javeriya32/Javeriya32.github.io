# Demo Script — 2 to 3 minutes (friendly, human tone)

Start recording. Keep voice calm and natural.

1. Intro (10-15s)
Hi, I'm [Your Name]. This is InfoHub — a small single-page app I built for the ByteXL challenge. It bundles three utilities: Weather, Currency Converter, and a Quote Generator.

2. Quick overview of stack (10s)
Built with React (Vite) for the frontend and Node + Express for the backend. The frontend calls three simple `/api` endpoints.

3. Walkthrough — Weather (30s)
- Click "Weather" tab (or show it's default).
- Show "London" loaded automatically.
- Type "Mumbai" and click Get — highlight loading state briefly, then show temperature and description.
- Mention: it uses OpenWeatherMap when an API key is provided, otherwise returns a mock but realistic value.

4. Walkthrough — Currency Converter (30s)
- Click "Currency".
- Enter `1000` and Convert.
- Show converted USD and EUR values.
- Mention: uses an exchange-rate API if you configure a key, otherwise falls back to mock rates.

5. Walkthrough — Quote Generator (20s)
- Click "Quote" tab.
- Click "New Quote" a couple of times to show different quotes and how source can be 'quotable' or 'local'.

6. Error / loading demonstration (20s)
- Optionally show what happens if the server has no API key (server returns mock) or show a simulated error by pointing the client to an invalid server URL.

7. Closing (10s)
- Mention repo contains `README.md`, `.env.example`, and quick deployment instructions.
- Thank you — that's InfoHub.

End recording.
